// script.js - interactions: theme toggle, typed effect, nav indicator and active link, smooth scroll
document.addEventListener('DOMContentLoaded', ()=>{

  // THEME TOGGLE (stores preference in localStorage)
  const themeToggle = document.getElementById('themeToggle');
  const body = document.body;
  const saved = localStorage.getItem('theme');
  if(saved === 'light') body.classList.add('light');
  function updateIcon(){ themeToggle.innerHTML = body.classList.contains('light') ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>'; }
  updateIcon();
  themeToggle.addEventListener('click', ()=>{
    body.classList.toggle('light');
    localStorage.setItem('theme', body.classList.contains('light') ? 'light' : 'dark');
    updateIcon();
  });

  // TYPING EFFECT (simple)
  const words = ['Full-Stack Developer','UX / UI Designer','Freelancer'];
  let idx = 0; let char = 0; let forward = true;
  const el = document.getElementById('typed');
  function type(){ 
    const w = words[idx];
    if(forward){ el.textContent = w.slice(0, ++char); if(char===w.length){ forward=false; setTimeout(type,800); return;} }
    else { el.textContent = w.slice(0, --char); if(char===0){ forward=true; idx=(idx+1)%words.length; } }
    setTimeout(type, 80);
  }
  type();

  // NAV INDICATOR & active link
  const navLinks = document.querySelectorAll('.nav-link');
  const navBar = document.querySelector('.nav-links');
  const indicator = document.createElement('div');
  indicator.className='nav-indicator';
  navBar.style.position='relative';
  navBar.appendChild(indicator);

  function setIndicator(elm){
    const rect = elm.getBoundingClientRect();
    const parent = navBar.getBoundingClientRect();
    indicator.style.left = (rect.left - parent.left) + 'px';
    indicator.style.width = rect.width + 'px';
  }
  // init
  setIndicator(document.querySelector('.nav-link.active'));

  navLinks.forEach(link=>{
    link.addEventListener('click', (e)=>{
      e.preventDefault();
      navLinks.forEach(l=>l.classList.remove('active'));
      link.classList.add('active');
      setIndicator(link);
      const id = link.getAttribute('href').substring(1);
      const target = document.getElementById(id);
      if(target) window.scrollTo({ top: target.offsetTop - 80, behavior:'smooth' });
    });
  });

  // Update active link on scroll
  const sections = document.querySelectorAll('main section');
  window.addEventListener('scroll', ()=>{
    let current='home';
    sections.forEach(s=>{
      const top = s.offsetTop - 120;
      if(pageYOffset >= top) current = s.id;
    });
    navLinks.forEach(l=>{ l.classList.toggle('active', l.getAttribute('href')===('#'+current)); });
    const active = document.querySelector('.nav-link.active');
    if(active) setIndicator(active);
  });

  // portfolio horizontal scroll snap support: mouse wheel scroll horizontally on desktop
  const gallery = document.querySelector('.portfolio-horizontal');
  if(gallery){
    gallery.addEventListener('wheel', (e)=>{
      if(Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
        e.preventDefault();
        gallery.scrollLeft += e.deltaY;
      }
    }, {passive:false});
  }

  // contact form (just simulate)
  const form = document.getElementById('contactForm');
  if(form){
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      alert('Thanks — message sent (demo).');
      form.reset();
    });
  }

});
